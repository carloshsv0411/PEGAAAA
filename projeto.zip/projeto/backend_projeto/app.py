from flask import Flask
from flask_cors import CORS

from controllers.user_controller import user_routes
from controllers.livro_controller import livro_routes
from controllers.emprestimo_controller import emprestimo_routes
from controllers.avaliacao_controller import avaliacao_routes

app = Flask(__name__)
CORS(app)
app.register_blueprint(user_routes)
app.register_blueprint(livro_routes)
app.register_blueprint(emprestimo_routes)
app.register_blueprint(avaliacao_routes, url_prefix='/api')




if __name__ == "__main__":
    app.run(debug=True)