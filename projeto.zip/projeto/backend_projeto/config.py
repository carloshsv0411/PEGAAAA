DB_CONFIG = {
    "host": "127.0.0.1",
    "user": "root",
    "password": "",
    "database": "login",
    "port": "3306"
}

SECRET_KEY = "minha_chave_secreta"
